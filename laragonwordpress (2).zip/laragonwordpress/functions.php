<?php

/*
My Theme function
*/

// All Default Function
include_once('inc/default.php');

// Adding post_service
include_once('inc/custom_post.php');


// Theme css and jquery file calling
include_once('inc/enqueue.php');


// Theme Funtion 
include_once('inc/theme_funtion.php');


// Menu Register
include_once('inc/menu_register.php');


// Widgets Register
include_once('inc/widgets_register.php');


// Shortcode Register
include_once('inc/shortcode.php');