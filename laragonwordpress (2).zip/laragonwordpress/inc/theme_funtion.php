<?php


// Theme Funtion 
function hasan_logo_customizer_register($wp_customize){
  // Header area
  $wp_customize->add_section('hasan_header_area', array(
    'title' =>__('Header Area', 'hasan'),
    'description' => 'If you interested your header area, you can do it here.',
  ));
  $wp_customize->add_setting('hasan_logo', array(
    'default' => get_bloginfo('template_directory') .'/img/logo.png',
  ));
  $wp_customize-> add_control(new WP_Customize_Image_Control($wp_customize, 'hasan_logo', array(
    'label' => 'Logo Upload',
    'description' => 'If you interested your header area, you can do it here.',
    'setting' => 'hasan_logo',
    'section' => 'hasan_header_area', 
  )));
  
  // Menu position
  $wp_customize->add_section('hasan_menu_option', array(
    'title' =>__('Menu position option', 'hasan'),
    'description' => 'If you interested to change you menu position, you can do it here.',
  ));
  $wp_customize->add_setting('hasan_menu_position', array(
    'default' => 'right_menu',
  ));
  $wp_customize-> add_control('hasan_menu_position', array(
    'label' => 'Logo Upload',
    'description' => 'Select your menu position.',
    'setting' => 'hasan_menu_position',
    'section' => 'hasan_menu_option',
    'type'    => 'radio',
    'choices'    => array(
      'left_menu' => 'Left Menu',
      'right_menu' => 'Right Menu',
      'center_menu' => 'Center Menu',
    ),
  ));



// Footer position
$wp_customize->add_section('hasan_footer_option', array(
  'title' =>__('Footer option', 'hasan'),
  'description' => 'If you interested to change you footer setting, you can do it here.',
));
$wp_customize->add_setting('hasan_copyright_section', array(
  'default' => '&copy; Copyright 2024 | Ratul Hasan',
));
$wp_customize-> add_control('hasan_copyright_section', array(
  'label' => 'Copyright text',
  'description' => 'If you interested to change you copyright text, you can do it here.',
  'setting' => 'hasan_copyright_section',
  'section' => 'hasan_footer_option',
));


// Theme color
$wp_customize->add_section('hasan_theme_color', array(
  'title' =>__('Theme color', 'hasan'),
  'description' => 'If you interested to change your theme color, you can do it here.',
));
$wp_customize->add_setting('hasan_bg_color', array(
  'default' => '#ffffff',
));
$wp_customize-> add_control( new WP_Customize_Color_Control($wp_customize, 'hasan_bg_color', array(
  'label' => 'Background Color',
  'setting' => 'hasan_bg_color',
  'section' => 'hasan_theme_color',
)));


$wp_customize->add_setting('hasan_primary_color', array(
  'default' => '#ea1a70',
));
$wp_customize-> add_control( new WP_Customize_Color_Control($wp_customize, 'hasan_primary_color', array(
  'label' => 'primary Color',
  'setting' => 'hasan_primary_color',
  'section' => 'hasan_theme_color',
)));


}
add_action('customize_register' , 'hasan_logo_customizer_register');


function hasan_theme_color_cu(){
  ?>
  <style>
    body{background: <?php echo get_theme_mod('hasan_bg_color') ?>}
    :root{--pink: <?php echo get_theme_mod('hasan_primary_color') ?>}
  </style>
  <?php
}
add_action('wp_head', 'hasan_theme_color_cu');