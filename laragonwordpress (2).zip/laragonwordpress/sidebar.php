<?php

// sidebar area

?>

<?php dynamic_sidebar('sidebar-1'); ?>